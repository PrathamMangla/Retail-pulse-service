package api

import (
	"encoding/json"
	"io/ioutil"
	"net/http"
	"retail-pulse-service/models"
	"retail-pulse-service/services"
	"strconv"
)

type SubmitJobRequest struct {
	Count  int         `json:"count"`
	Visits []VisitData `json:"visits"`
}

type VisitData struct {
	StoreID   string   `json:"store_id"`
	ImageURL  []string `json:"image_url"`
	VisitTime string   `json:"visit_time"`
}

type SubmitJobResponse struct {
	JobID int `json:"job_id"`
}

func SubmitJob(w http.ResponseWriter, r *http.Request) {
	var request SubmitJobRequest

	// Parse the request body
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	// Unmarshal JSON data
	err = json.Unmarshal(body, &request)
	if err != nil {
		http.Error(w, "Error parsing JSON", http.StatusBadRequest)
		return
	}

	// Validate input
	if request.Count != len(request.Visits) {
		http.Error(w, "Count does not match the number of visits", http.StatusBadRequest)
		return
	}

	// Convert `[]VisitData` from `api` package to `[]models.VisitData`
	var visits []models.VisitData
	for _, visit := range request.Visits {
		visits = append(visits, models.VisitData{
			StoreID:   visit.StoreID,
			ImageURLs: visit.ImageURL,
			VisitTime: visit.VisitTime,
		})
	}

	// Process the job and save it
	jobID, err := services.CreateJob(visits)
	if err != nil {
		http.Error(w, "Error creating job", http.StatusInternalServerError)
		return
	}

	// Respond with the job ID
	response := SubmitJobResponse{JobID: jobID}
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(response)
}

func GetJobInfo(w http.ResponseWriter, r *http.Request) {
	jobIDStr := r.URL.Query().Get("jobid")
	if jobIDStr == "" {
		http.Error(w, "Missing jobid parameter", http.StatusBadRequest)
		return
	}

	jobID, err := strconv.Atoi(jobIDStr)
	if err != nil {
		http.Error(w, "Invalid jobid", http.StatusBadRequest)
		return
	}

	status, err := services.GetJobStatus(jobID)
	if err != nil {
		http.Error(w, "Error retrieving job status", http.StatusInternalServerError)
		return
	}

	if status == nil {
		http.Error(w, "Job ID not found", http.StatusBadRequest)
		return
	}

	// Respond with the job status
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(status)
}
