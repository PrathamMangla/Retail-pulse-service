package models

import "time"

type ErrorDetails struct {
	StoreID string `json:"store_id"`
	Error   string `json:"error"`
}

type Job struct {
	JobID     int            `json:"job_id"`
	Visits    []VisitData    `json:"visits"`
	JobStatus string         `json:"status"`
	CreatedAt time.Time      `json:"created_at"`
	Errors    []ErrorDetails `json:"errors"` // Add this field
}

type VisitData struct {
	StoreID   string   `json:"store_id"`
	ImageURLs []string `json:"image_urls"`
	VisitTime string   `json:"visit_time"`
}
