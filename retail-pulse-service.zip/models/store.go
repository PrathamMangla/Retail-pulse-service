package models

type Store struct {
	AreaCode  string `csv:"AreaCode"`
	StoreName string `csv:"StoreName"`
	StoreID   string `csv:"StoreID"`
}
