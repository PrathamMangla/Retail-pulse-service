package services

import (
	"bytes"
	"fmt"
	"image"
	"image/gif"
	"image/jpeg"
	"image/png"
	"io"
	"math/rand"
	"net/http"
	"retail-pulse-service/models"
	"retail-pulse-service/utils"
	"time"

	"golang.org/x/image/webp"
	// Import the WebP package
	// Import the WebP package
)

var jobs []models.Job
var jobCounter int

func CreateJob(visits []models.VisitData) (int, error) {
	// Increment job counter and create new job
	jobCounter++
	newJob := models.Job{
		JobID:     jobCounter,
		Visits:    visits,
		JobStatus: "processing",
		CreatedAt: time.Now(),
		Errors:    []models.ErrorDetails{},
	}

	jobs = append(jobs, newJob)

	// Simulate job processing asynchronously
	go processImages(newJob.JobID, visits)

	return newJob.JobID, nil
}

// Process images for the given job
func processImages(jobID int, visits []models.VisitData) {
	for _, visit := range visits {
		for _, imageURL := range visit.ImageURLs {
			// Log the image URL being processed
			fmt.Printf("Processing image: %s\n", imageURL)

			// Download the image
			err := utils.DownloadImage(imageURL)
			if err != nil {
				// If download fails, log the error and update the job status to failed
				fmt.Printf("Error downloading image from URL: %s, Error: %s\n", imageURL, err.Error())
				updateJobStatus(jobID, "failed", visit.StoreID, err.Error())
				return
			}

			// Calculate perimeter of the image (actual calculation using image dimensions)
			perimeter, err := calculateImagePerimeter(imageURL)
			if err != nil {
				// Handle error if unable to calculate perimeter
				fmt.Printf("Error calculating perimeter for image %s, Error: %s\n", imageURL, err.Error())
				updateJobStatus(jobID, "failed", visit.StoreID, err.Error())
				return
			}
			fmt.Printf("Processed image: %s, perimeter: %d\n", imageURL, perimeter)

			// Random sleep to imitate processing time
			time.Sleep(time.Duration(rand.Intn(400)+100) * time.Millisecond)
		}
	}

	// Mark job as completed after processing all images
	updateJobStatus(jobID, "completed", "", "")
}

// Calculate the perimeter of the image (handles both WebP and JPEG formats)
func calculateImagePerimeter(imageURL string) (int, error) {
	// Download the image
	resp, err := http.Get(imageURL)
	if err != nil {
		return 0, fmt.Errorf("failed to download image: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return 0, fmt.Errorf("failed to download image from URL %s: received status code %d", imageURL, resp.StatusCode)
	}

	// Log the Content-Type for debugging
	fmt.Println("Content-Type:", resp.Header.Get("Content-Type"))

	// Read the image body into a buffer
	buf := new(bytes.Buffer)
	_, err = io.Copy(buf, resp.Body)
	if err != nil {
		return 0, fmt.Errorf("failed to read image body: %v", err)
	}

	// Log the size of the buffer to confirm the image data size
	fmt.Println("Image data size:", buf.Len())

	// Check the first few bytes to verify the format (JPEG should start with 0xFF, 0xD8)
	fmt.Printf("First few bytes of the image data: %x\n", buf.Bytes()[:10])

	// Detect image type using the first few bytes
	contentType := http.DetectContentType(buf.Bytes())
	var img image.Image

	switch contentType {
	case "image/jpeg":
		img, err = jpeg.Decode(buf)
		if err != nil {
			return 0, fmt.Errorf("failed to decode JPEG image: %v", err)
		}
	case "image/png":
		img, err = png.Decode(buf)
		if err != nil {
			return 0, fmt.Errorf("failed to decode PNG image: %v", err)
		}
	case "image/gif":
		img, err = gif.Decode(buf)
		if err != nil {
			return 0, fmt.Errorf("failed to decode GIF image: %v", err)
		}
	case "image/webp":
		// For WebP images, use the golang.org/x/image/webp package (requires importing)
		img, err = webp.Decode(buf)
		if err != nil {
			return 0, fmt.Errorf("failed to decode WebP image: %v", err)
		}
	default:
		return 0, fmt.Errorf("unsupported image format: %s", contentType)
	}

	// Get the dimensions of the image
	bounds := img.Bounds()
	width := bounds.Dx()
	height := bounds.Dy()

	// Calculate the perimeter
	perimeter := 2 * (width + height)
	return perimeter, nil
}

// Update the job status
func updateJobStatus(jobID int, status string, storeID string, errorMsg string) {
	for i, job := range jobs {
		if job.JobID == jobID {
			if status == "failed" {
				job.JobStatus = status
				job.Errors = append(job.Errors, models.ErrorDetails{
					StoreID: storeID,
					Error:   errorMsg,
				})
			} else {
				job.JobStatus = status
			}
			jobs[i] = job
			break
		}
	}
}

// Get the status of a job by job ID
func GetJobStatus(jobID int) (*models.Job, error) {
	for _, job := range jobs {
		if job.JobID == jobID {
			return &job, nil
		}
	}
	return nil, fmt.Errorf("job not found")
}
