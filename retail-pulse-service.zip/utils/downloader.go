package utils

import (
	"encoding/csv"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"retail-pulse-service/models"
)

func DownloadImage(url string) error {
	// Get the current directory where the code is running
	currentDir, err := os.Getwd()
	if err != nil {
		return fmt.Errorf("failed to get current directory: %v", err)
	}

	// Define the folder path as "downloaded_images" within the current directory
	folderPath := filepath.Join(currentDir, "downloaded_images")

	// Create the folder if it doesn't exist
	if _, err := os.Stat(folderPath); os.IsNotExist(err) {
		err := os.MkdirAll(folderPath, os.ModePerm)
		if err != nil {
			return fmt.Errorf("failed to create folder %s: %v", folderPath, err)
		}
	}

	// Extract the image name from the URL
	imageName := filepath.Base(url)

	// Define the file path where the image will be saved
	imagePath := filepath.Join(folderPath, imageName)

	// Download the image from the URL
	resp, err := http.Get(url)
	if err != nil {
		return fmt.Errorf("failed to download image from URL %s: %v", url, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("failed to download image from URL %s: received status code %d", url, resp.StatusCode)
	}

	// Create the file to save the image
	file, err := os.Create(imagePath)
	if err != nil {
		return fmt.Errorf("failed to create file %s: %v", imagePath, err)
	}
	defer file.Close()

	// Save the image data to the file
	_, err = io.Copy(file, resp.Body)
	if err != nil {
		return fmt.Errorf("failed to save image to file %s: %v", imagePath, err)
	}

	fmt.Printf("Image downloaded successfully from URL: %s and saved to %s\n", url, imagePath)
	return nil
}

// LoadStoreData loads store data from the CSV file and returns a slice of Store structs.
func LoadStoreData(filePath string) ([]models.Store, error) {
	// Open the CSV file
	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("failed to open file %s: %v", filePath, err)
	}
	defer file.Close()

	// Read the CSV file
	reader := csv.NewReader(file)
	records, err := reader.ReadAll()
	if err != nil {
		return nil, fmt.Errorf("failed to read CSV file %s: %v", filePath, err)
	}

	// Parse records into store data
	var stores []models.Store
	for i, record := range records {
		if i == 0 {
			// Skip the header row
			continue
		}
		if len(record) < 3 {
			log.Printf("Skipping invalid record on line %d: %v\n", i+1, record)
			continue
		}
		store := models.Store{
			AreaCode:  record[0],
			StoreName: record[1],
			StoreID:   record[2],
		}
		stores = append(stores, store)
	}

	return stores, nil
}
