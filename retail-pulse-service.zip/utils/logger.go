package utils

import (
	"log"
	"os"
)

var logger *log.Logger

// InitLogger initializes the logger and sets up the log file.
func InitLogger() error {
	file, err := os.OpenFile("retail-pulse.log", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil {
		return err
	}
	logger = log.New(file, "", log.Ldate|log.Ltime|log.Lshortfile)
	return nil
}

// Log writes a message to the log file.
func Log(message string) {
	if logger == nil {
		// Fallback to standard logger if not initialized
		log.Println("Logger not initialized. Message:", message)
	} else {
		logger.Println(message)
	}
}

// LogError writes an error message to the log file.
func LogError(err error) {
	if logger == nil {
		// Fallback to standard logger if not initialized
		log.Println("Logger not initialized. Error:", err)
	} else {
		logger.Println("ERROR:", err)
	}
}
